package com.example.dailyexpenses;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.dailyexpanses.R;

public class listbulanan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listbulanan);
    }
}
