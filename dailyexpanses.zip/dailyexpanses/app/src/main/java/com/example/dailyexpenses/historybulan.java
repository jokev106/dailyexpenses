package com.example.dailyexpenses;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.dailyexpanses.R;

public class historybulan extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.historybulan);

    }
}
